package csms;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Client {
    
    private final SimpleIntegerProperty clientId = new SimpleIntegerProperty();
    private final SimpleStringProperty clientName = new SimpleStringProperty();
    
    public Client(int clientId, String clientNameIn){
        setClientId(clientId);
        
    }
    
    public int getClientId() {
        return clientId.get();
    }
    public void setClientId(int clientId) {
        this.clientId.set(clientId);
    }
    
    public String getClientName() {
        return clientName.get();
    }
    
    public void setClientName(String clientNameIn) {
        clientName.set(clientNameIn);
    }
    
    
    
    
    
}